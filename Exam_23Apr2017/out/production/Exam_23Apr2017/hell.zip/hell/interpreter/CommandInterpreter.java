package hell.interpreter;

import hell.factories.ItemFactory;
import hell.interfaces.*;

/**
 * Created by gery on 23.4.2017 г. at 16:04.
 */
public class CommandInterpreter implements Interpreter {

    private Hell hellSystem;
    private HeroCreatable heroFactory;
    private ItemCreatable itemFactory;
    private RecipeCreatable recipeFactory;

    public CommandInterpreter(Hell hellSystem, HeroCreatable heroFactory, ItemCreatable itemFactory, RecipeCreatable recipeFactory) {
        this.hellSystem = hellSystem;
        this.heroFactory = heroFactory;
        this.itemFactory = itemFactory;
        this.recipeFactory = recipeFactory;
    }

    @Override
    public String interpretCommand(String input) {
        String[] arguments = input.split("\\s+");
        String commandName = arguments[0];
        String output = null;
        switch (commandName) {
            case "Hero":
                Hero hero = heroFactory.createHero(arguments);
                if(null != hero){
                    output = this.hellSystem.addHero(hero);
                }
                break;
            case "Item":
                Item item = itemFactory.createItem(arguments);
                if(null != item) {
                    output = this.hellSystem.addItemToHero(arguments[2], item);
                }
                break;
            case "Recipe":
                Recipe recipe = recipeFactory.createRecipe(arguments);
                if(null != recipe) {
                    output = this.hellSystem.addRecipeToHero(arguments[2], recipe);
                }
                break;
            case "Inspect":
                output = this.hellSystem.inspect(arguments[1]);
                break;
            default:
                break;

        }
        return output;
    }
}
