package hell;

import hell.core.Engine;
import hell.factories.HeroFactory;
import hell.factories.ItemFactory;
import hell.factories.RecipeFactory;
import hell.interfaces.Hell;
import hell.interfaces.Interpreter;
import hell.interfaces.ItemCreatable;
import hell.interfaces.RecipeCreatable;
import hell.interpreter.CommandInterpreter;
import hell.io.ConsoleReader;
import hell.io.ConsoleWriter;
import hell.io.Reader;
import hell.io.Writer;

public class Main {
    public static void main(String[] args) {

        Hell hell = new HellSystem();
        HeroFactory factory = new HeroFactory();
        ItemCreatable itemFactory = new ItemFactory();
        RecipeCreatable recipeFactory = new RecipeFactory();
        Interpreter interpreter = new CommandInterpreter(hell, factory, itemFactory, recipeFactory);
        Reader reader = new ConsoleReader();
        Writer writer = new ConsoleWriter();

        Runnable engine = new Engine(reader, writer, hell, interpreter);
        engine.run();
    }
}