package hell.entities.items;

/**
 * Created by gery on 23.4.2017 г. at 15:37.
 */
public class CommonItem extends BaseItem {

    public CommonItem(String name, int strengthBonus, int agilityBonus, int intelligenceBonus, int hitPointsBonus, int damageBonus) {
        super(name, strengthBonus, agilityBonus, intelligenceBonus, hitPointsBonus, damageBonus);
    }
}
