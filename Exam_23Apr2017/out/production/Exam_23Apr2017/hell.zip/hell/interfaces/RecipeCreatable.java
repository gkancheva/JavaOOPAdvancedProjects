package hell.interfaces;

/**
 * Created by gery on 23.4.2017 г. at 20:10.
 */
public interface RecipeCreatable {
    Recipe createRecipe(String[] args);
}
