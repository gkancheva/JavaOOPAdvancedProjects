package hell.interfaces;

/**
 * Created by gery on 23.4.2017 г. at 16:47.
 */
public interface ItemCreatable {
    Item createItem(String[] args);
}
