package hell.io;

import java.io.IOException;

/**
 * Created by gery on 23.4.2017 г. at 16:32.
 */
public interface Reader {

    String read() throws IOException;
}
