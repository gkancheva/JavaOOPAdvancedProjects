package hell.io;

/**
 * Created by gery on 23.4.2017 г. at 16:32.
 */
public interface Writer {
    void write(String text);
    void writeLine(String text);
}
