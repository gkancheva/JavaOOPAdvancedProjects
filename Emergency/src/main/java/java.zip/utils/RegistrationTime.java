package utils;

public interface RegistrationTime {
    String toString();
}
