package io;

public interface Writer {
    void write(String text);
}
