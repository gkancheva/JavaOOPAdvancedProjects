package models.centers;

public class MedicalServiceCenter extends BaseEmergencyCenter{

    public MedicalServiceCenter(String name, Integer amountOfMaximumEmergencies) {
        super(name, amountOfMaximumEmergencies);
    }
}
