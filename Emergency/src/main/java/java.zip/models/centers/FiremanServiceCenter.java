package models.centers;

public class FiremanServiceCenter extends BaseEmergencyCenter{

    public FiremanServiceCenter(String name, Integer amountOfMaximumEmergencies) {
        super(name, amountOfMaximumEmergencies);
    }
}
