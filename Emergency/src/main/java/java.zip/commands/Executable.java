package commands;

public interface Executable {
    String execute();
}
