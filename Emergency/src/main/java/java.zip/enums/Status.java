package enums;

/**
 * Created by gery on 18.4.2017 г. at 13:13.
 */
public enum Status {
    SPECIAL,
    NON_SPECIAL
}
